package com.dheeraj.tapper;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
