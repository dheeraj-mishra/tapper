import 'package:flutter/material.dart';
import 'package:system_alert_window/system_alert_window.dart';

void main(){
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Home(),
      theme: ThemeData.dark(),
    );
  }
}

class Home extends StatefulWidget {

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int totalCount = 0;
  @override
  void initState(){
    super.initState();
    getPermission();
  }

  Future<void> getPermission() async {
    await SystemAlertWindow.requestPermissions();
  }
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        setState(() {
          totalCount++;
        });
      },
      child: Scaffold(
        appBar: AppBar(
          title: Center(child: Text("Tap Counter")),
        ),
        body: Center(
            child: ElevatedButton(
              onPressed: (){
                totalCount++;
                print(totalCount);
              },
              child: Text("Press me"),
            )
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: (){
            setState(() {
              totalCount = 0;
            });
          },
          backgroundColor: Colors.white,
          child: Text("reset"),
        ),
      ),
    );
  }
}

// Text(
// "You have tapped your screen $totalCount times.",
// style: TextStyle(
// // color: Colors.yellow
// ),
// ),